#if !defined(AFX_DIALOGDUMP_H__481C5966_558F_4F68_B2C7_A21ACA364147__INCLUDED_)
#define AFX_DIALOGDUMP_H__481C5966_558F_4F68_B2C7_A21ACA364147__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DialogDump.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDialogDump dialog

class CDialogDump : public CDialog
{
// Construction
public:
	CDialogDump(CWnd* pParent = NULL, const CListContour* pList=NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDialogDump)
	enum { IDD = IDD_DIALOG_DUMP };
	CString	m_strText;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDialogDump)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	const CListContour* m_pListContour;

	// Generated message map functions
	//{{AFX_MSG(CDialogDump)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIALOGDUMP_H__481C5966_558F_4F68_B2C7_A21ACA364147__INCLUDED_)

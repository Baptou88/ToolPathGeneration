// DialogDump.cpp : implementation file
//

#include "stdafx.h"
#include <strstream>
#include "contourgl.h"
#include "ListContour.h"
#include "DialogDump.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDialogDump dialog


CDialogDump::CDialogDump(CWnd* pParent /*=NULL*/, const CListContour* pListContour)
	: CDialog(CDialogDump::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDialogDump)
	m_strText = _T("");
	//}}AFX_DATA_INIT

	m_pListContour=pListContour;
}


void CDialogDump::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDialogDump)
	DDX_Text(pDX, IDC_EDIT_DUMP, m_strText);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDialogDump, CDialog)
	//{{AFX_MSG_MAP(CDialogDump)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDialogDump message handlers

BOOL CDialogDump::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	ASSERT(m_pListContour);

	if (m_pListContour->GetNPlanes()==0)
		return TRUE;


	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

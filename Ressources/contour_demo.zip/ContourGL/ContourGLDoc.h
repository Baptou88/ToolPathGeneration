// ContourGLDoc.h : interface of the CContourGLDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CONTOURGLDOC_H__62BDAD97_C443_4D3F_B28D_A295559B60A3__INCLUDED_)
#define AFX_CONTOURGLDOC_H__62BDAD97_C443_4D3F_B28D_A295559B60A3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "GLContour.h"
#include "ListContour.h"

class CContourGLDoc : public CDocument
{
protected: // create from serialization only
	CContourGLDoc();
	DECLARE_DYNCREATE(CContourGLDoc)

// Attributes
public:

// Operations
public:
	CListContour* GetListContour() {	 return &m_listContour;};

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CContourGLDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	void GetGLLimits(double pLimits[4]);
	void Draw();
	virtual ~CContourGLDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	CListContour m_listContour;
	
// Generated message map functions
protected:
	//{{AFX_MSG(CContourGLDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
void line2(double x1, double y1, double x2, double y2);

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONTOURGLDOC_H__62BDAD97_C443_4D3F_B28D_A295559B60A3__INCLUDED_)

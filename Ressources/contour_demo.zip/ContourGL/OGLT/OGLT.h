#ifndef OGLT_H
	#define OGLT_H

#ifndef OGLTOOLS_EXT_CLASS
	#ifdef _OGLTOOLS_DLL
		#define OGLTOOLS_EXT_CLASS _declspec(dllexport)
	#else
		#define OGLTOOLS_EXT_CLASS _declspec(dllimport)
	#endif
#endif

	#include <GL/gl.h>
	#include <GL/glu.h>
	#include "CWGL.h"
	#include "CGLImage.h"
	#include "CGLTexture.h"
	#include "CRGBSurface.h"
#endif

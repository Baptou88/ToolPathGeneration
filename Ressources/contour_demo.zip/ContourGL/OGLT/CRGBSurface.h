

#ifndef _CRGBSURFACE_H_
#define _CRGBSURFACE_H_

// Make integer i divideable by integer a
#define ALIGN(i, a) (((i) + ((a) - 1))/(a)*(a))

// Convert from COLORREF to DIB's BGRA
inline DWORD COLORREFtoBGRA(COLORREF cr, BYTE bAlpha = 255)
{
	return ((DWORD(bAlpha)) << 24) + RGB(GetBValue(cr), GetGValue(cr), GetRValue(cr));
}

inline DWORD ReverseRGB(COLORREF cr, BYTE bAlpha = 255)
{
	return COLORREFtoBGRA(cr, bAlpha);
}

#define RGBA(b,g,r,a)       ((COLORREF)(((BYTE)(r)|((WORD)((BYTE)(g))<<8))|(((DWORD)(BYTE)(b))<<16))|(((DWORD)(BYTE)(a))<<24))

// 24 and 32 bit DIB's pixelformat
#define BGR(b,g,r)          ((COLORREF)(((BYTE)(b)|((WORD)((BYTE)(g))<<8))|(((DWORD)(BYTE)(r))<<16)))
#define BGRA(b,g,r,a)       ((COLORREF)(((BYTE)(b)|((WORD)((BYTE)(g))<<8))|(((DWORD)(BYTE)(r))<<16))|(((DWORD)(BYTE)(a))<<24))


/*! \brief A wraper to a 24 bit or 32 bit RGB DIB section GDI object.

\ingroup OGLToolsGroup
CRGBSurface is a wraper to a 24 bit or 32 bit RGB
DIB section GDI object.
After creating a RGB surface with one of its Create() methods,
use GetDC() to access a surface thrugh it's DC or
GetPixels() to directly access the surface RGB pixels.
Use Draw() for easy drawing of RGB DIB section
and CopyToClipboard() for copying or seting RGB DIB section
to clipboard.

Call DeleteDC() if you no longer need the surface's DC
(Draw() and Blt() functions don't need it).


 With CRGBSurface you can:
<ol>
<li> Create an empty 24 or 32 bit RGB DIB section.
<li> Convert a device dependent bitmap, passed as
     HBITMAP or CBitmap, to 24 or 32 RGB DIB section.
<li> Create a 24 or 32 RGB DIB section from
     a DIB or JPEG file on disk.
<li> Save a DIB section to disk in bitmap or JPEG format.
<li> Draw() and Blt() a DIB section to a DC.
</ol>

\sa CGLImage
\sa CWGL
\author (c) W.Weyna 'Voytec', http://shiptech.tuniv.szczecin.pl/~weyna/OpenGL/
*/
class OGLTOOLS_EXT_CLASS CRGBSurface
{
// Construction
public:
	CRGBSurface();
	virtual ~CRGBSurface();

// Attributes
public:
	/*! Attributes:*/
	//@{
	//! returns device context associated with DIB section object selected into it.
	CDC* GetDC() const {return m_pDC;}	      
	//! returns a handle to DIB section GDI object
	HBITMAP GetHandle() const {return m_hDIBSection;}  
	//! returns a pointer for a direct access to 24 or 32 bit RGB pixels of DIB section
	BYTE* GetPixels() const {GdiFlush(); return m_pDIBits; } 

	/*! \name  Image sizes in pixels*/
	//@{
	//! returns a CSize structure containing size of DIB
	CSize GetSize() const {return CSize(m_bih.biWidth, m_bih.biHeight); };
	//! width (in pixels) of DIB
	int GetWidth() const {return m_bih.biWidth; };
	//! height (in pixels) of DIB
	int GetHeight() const {return m_bih.biHeight; };
	//@}

	/*! \name  Image sizes in bytes*/
	//@{
	//! returns number of bytes per row of DIB
	DWORD GetRowSize_Bytes() const { return m_bih.biWidth * m_bih.biBitCount / 8; }
	//! returns number of aligned bytes per row of DIB
	DWORD GetAlignedRowSize_Bytes() const { return ALIGN(GetRowSize_Bytes(), 4); }
	//! returns size (in bytes) of DIB
	DWORD GetSize_Bytes() const { return GetAlignedRowSize_Bytes() * m_bih.biHeight; }

	//! Image size in bytes for m_bih.biBitCount = 24.
	DWORD GetSize24_Bytes() const { return ALIGN(m_bih.biWidth * 3, 4) * m_bih.biHeight; }
	//@}

	/*! \name  Image sizes in logical units*/
	//@{
	//! returns Size log
	CSize GetSizeLog(CDC* pDC) const {
		CSize imageSize(m_bih.biWidth, m_bih.biHeight);
		pDC->DPtoLP(&imageSize);
		return imageSize; }
	//@}

	//! Get bitmap info of DIB
	const BITMAPINFOHEADER* GetBIH() const {return &m_bih; }
	//! returns size in pixels
	int GetPixelSize_Bytes() {return m_bih.biBitCount / 8; }
	//! internal.
	bool CheckSaveError_FileExists(){ return m_bSaveFile_FileExists; }
	//@}

protected:
	HBITMAP m_hDIBSection;
	HBITMAP m_hDIBSectionOld;
	BYTE* m_pDIBits;	

	CDC* m_pDC;
	BITMAPINFOHEADER m_bih;

	bool m_bSaveFile_FileExists;

// Operations
public:    
	/*! @name Operations: */
	//@{
	bool Create(CRGBSurface* const pSourceSurface);
	bool Create(int cx, int cy, int nBitsPerPixel = 24);
	bool Create(BYTE* pDIB, int nBitsPerPixel = 24);
	bool Create(HANDLE hFile, int nBitsPerPixel = 24);
	bool Create(const char* szPath, int nBitsPerPixel = 24);
	bool Create(HBITMAP hBitmap, int nBitsPerPixel = 24, CDC* pBitmapDC = NULL);
	//! Create DIB using Create(HBITMAP,int,CDC*)
	bool Create(CBitmap* pBitmap, int nBitsPerPixel = 24, CDC* pBitmapDC = NULL) {return Create(HBITMAP(*pBitmap), nBitsPerPixel, pBitmapDC); }
	//! Create DIB using Create(HBITMAP,int,CDC*)
	bool Create(const CBitmap& bitmap, int nBitsPerPixel = 24, CDC* pBitmapDC = NULL) {return Create(HBITMAP(bitmap), nBitsPerPixel, pBitmapDC); }

	void Draw(CDC* pDestDC, int x, int y, int destWidth = -1, int destHeight  = -1) const; 
	void Draw(CDC* pDestDC, int srcx, int srcy, int srcWidth, int srcHeight,int destx, int desty, int destWidth =-1, int destHeight=-1)  const;
	void Blt(CDC* pDestDC) const;
	bool CopyTo(CRGBSurface* pDestSurface, DWORD dwDestX = 0, DWORD dwDestY = 0) const;
	bool CopyToClipboard(bool bNoCopy = false); 
	bool SaveToFile(const CString& strPath, bool bAllowOverwrite = false, int nQuality = -1); 
	
	BYTE* CreateDIB();
	HGLOBAL CreateDIB_Win16();

	void Delete();
	void DeleteDC();
	bool RecreateDC();
	
	BYTE* LoadDIB(const CString& strPath);
	BYTE* LoadDIBFromOpenedFile(HANDLE hFile);
	bool SaveDIBToOpenedFile(HANDLE hFile);
	bool SaveDIB(const CString& strPath, bool bAllowOverwrite = false);
	bool SaveAsJPEGFile(const CString& strPath, int nQuality = -1, bool bAllowOverwrite = false);
	bool CreateFromJPEGFile(const CString& strPath, int nBitsPerPixel = 24);
	bool CreateFromOpenedStdioJPEGFile(FILE* infile, int nBitsPerPixel = 24);
	bool CreateFromDIBFile(const CString& strPath, int nBitsPerPixel = 24);
	//@}


// Operations that directly manipulate the DIB bits
public:
	/*! @name Operations that directly manipulate the DIB bits: */
	//@{
	void Clear(DWORD dwBGRA = BGRA(255, 255, 255, 255));
	void ClearCR(DWORD dwRGBA = RGBA(255, 255, 255, 255));
	void Brightness(double dBrightness);
	//@}	
// Validity check
public:

#ifdef _DEBUG
	void AssertValid() const {
		ASSERT_VALID(m_pDC);
		ASSERT(m_hDIBSection);
		ASSERT(m_pDIBits);
		ASSERT(m_bih.biBitCount == 24 || m_bih.biBitCount == 32);
		ASSERT(m_bih.biWidth > 0);
		ASSERT(m_bih.biHeight > 0);
		ASSERT(GetObjectType(m_hDIBSection) == OBJ_BITMAP); }
#else
	void AssertValid() {};
#endif
	
// Helpers
private:
	BYTE* GetPointerToDIBits(BYTE* pDIB);

// Friends
	friend bool operator==(const CRGBSurface& l, const CRGBSurface& r);
	friend bool operator!=(const CRGBSurface& l, const CRGBSurface& r);

};

inline bool operator>(const CRGBSurface& l, const CRGBSurface& r)
{
	return l.GetWidth() > r.GetWidth() &&
		l.GetHeight() > r.GetHeight();
}

inline bool operator>=(const CRGBSurface& l, const CRGBSurface& r) 
{
	return l.GetWidth() >= r.GetWidth() &&
		l.GetHeight() >= r.GetHeight();
}

inline bool operator<(const CRGBSurface& l, const CRGBSurface& r) 
{
	return l.GetWidth() < r.GetWidth() &&
		l.GetHeight() < r.GetHeight();
}

inline bool operator<=(const CRGBSurface& l, const CRGBSurface& r)
{
	return l.GetWidth() <= r.GetWidth() &&
		l.GetHeight() <= r.GetHeight();
}

inline bool operator==(const CRGBSurface& l, const CRGBSurface& r) 
{
	return l.GetWidth() == r.GetWidth() &&
		l.GetHeight() == r.GetHeight() && 
		l.m_bih.biBitCount == r.m_bih.biBitCount;
}

inline bool operator!=(const CRGBSurface& l, const CRGBSurface& r) 
{
	return l.GetWidth() != r.GetWidth() ||
		l.GetHeight() != r.GetHeight() ||
		l.m_bih.biBitCount != r.m_bih.biBitCount;
}

#endif 


//////////////////////////////////////////////////////////////////////
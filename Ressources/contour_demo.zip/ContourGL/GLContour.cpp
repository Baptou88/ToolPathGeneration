// GLContour.cpp: implementation of the CGLContour class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ContourGL.h"
#include "GLContour.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGLContour::CGLContour()
: CContour()
{

}

CGLContour::~CGLContour()
{

}

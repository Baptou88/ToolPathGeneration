// ContourGLView.cpp : implementation of the CContourGLView class
//

#include "stdafx.h"
#include "ContourGL.h"
#include "../Contour.h"

#include "ContourGLDoc.h"
#include "ContourGLView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CContourGLView

IMPLEMENT_DYNCREATE(CContourGLView, CView)

BEGIN_MESSAGE_MAP(CContourGLView, CView)
	//{{AFX_MSG_MAP(CContourGLView)
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_WM_KEYDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CContourGLView construction/destruction

CContourGLView::CContourGLView()
{
	// TODO: add construction code here

}

CContourGLView::~CContourGLView()
{
}

BOOL CContourGLView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CContourGLView drawing

void CContourGLView::OnDraw(CDC* pDC)
{
	CContourGLDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	CListContour* pListContour;
	
	double pLimits[4];

	pDoc->GetGLLimits(pLimits);

	m_view.SetLimits(pLimits);
	m_view.PostReshape();

	m_wgl.Begin(pDC);
		m_view.InitGLState();
		// setting view
		m_view.Reshape();	
		glPointSize(7.f);
		// clearing buffer
		glClearColor(1.0, 1.0, 1.0, 0.0);
 		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// drawing line
		pDoc->Draw();

		pListContour=pDoc->GetListContour();
		// draw text
		glColor3f(0.0, 0.0, 0.0);
		CString str;
		str.Format("First grid:%d x %d, Sec. grid: %d x %d, n Planes: %d",
			pListContour->GetRowFir(),
			pListContour->GetColFir(),
			pListContour->GetRowSec(),
			pListContour->GetColSec(),
			pListContour->GetNPlanes()		
			);
		glRasterPos2f(
			(GLfloat)(pLimits[0]+(pLimits[1]-pLimits[0])/m_view.GetWidth()*20),
			(GLfloat)(pLimits[3]-(pLimits[3]-pLimits[2])/m_view.GetHeight()*15)
		);
		m_wgl.TextOut(str);
		str.Format("a/q=increase/decrease first grid, o/p=increase/decrease sec. grid, e/d=inc./dec. planes");
		glRasterPos2f(
			(GLfloat)(pLimits[0]+(pLimits[1]-pLimits[0])/m_view.GetWidth()*20),
			(GLfloat)(pLimits[3]-(pLimits[3]-pLimits[2])/m_view.GetHeight()*30)
		);
		m_wgl.TextOut(str);
	m_wgl.End();	

	// Swap buffers.
	SwapBuffers(pDC->m_hDC) ;
}

/////////////////////////////////////////////////////////////////////////////
// CContourGLView diagnostics

#ifdef _DEBUG
void CContourGLView::AssertValid() const
{
	CView::AssertValid();
}

void CContourGLView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CContourGLDoc* CContourGLView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CContourGLDoc)));
	return (CContourGLDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CContourGLView message handlers

BOOL CContourGLView::OnEraseBkgnd(CDC* pDC) 
{
	return TRUE;
}

void CContourGLView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);

	m_view.SetViewport(0,0,cx,cy);

	m_view.PostReshape();	
}

void CContourGLView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
	
//	((CContourGLApp*)AfxGetApp())->SetView(this);	

	m_view.GetState()->SetLineWidth(1);
}

void CContourGLView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	CContourGLDoc* pDoc=GetDocument();
	CListContour* pListContour=pDoc->GetListContour();
	int i,np;
	std::vector<double> vPlanes;

	switch(nChar)
	{
	case 65:
		pListContour->SetFirstGrid(pListContour->GetColFir()+5,pListContour->GetRowFir()+5);
		break;
	case 81:
		pListContour->SetFirstGrid(pListContour->GetColFir()-5,pListContour->GetRowFir()-5);
		break;
	case 79:
		pListContour->SetSecondaryGrid(pListContour->GetColSec()+32,pListContour->GetRowSec()+32);
		break;
	case 80:
		pListContour->SetSecondaryGrid(pListContour->GetColSec()-32,pListContour->GetRowSec()-32);
		break;
	case 69:
		np=pListContour->GetNPlanes()+1;
		vPlanes.resize(np);
		for (i=0;i<np;i++)
		{
			vPlanes[i]=(i-(double)np/2.) / ((double)np/2.) *2.;
		}
		pListContour->SetPlanes(vPlanes);
		break;
	case 68:
		np=max(1,pListContour->GetNPlanes()-1);
		vPlanes.resize(np);
		for (i=0;i<np;i++)
		{
			vPlanes[i]=(i-(double)np/2.) / ((double)np/2.) *2.;
		}
		pListContour->SetPlanes(vPlanes);
		break;
	}	
	CView::OnKeyDown(nChar, nRepCnt, nFlags);

	InvalidateRect(NULL,FALSE);
}
